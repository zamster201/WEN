from PySide6.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QPushButton, QApplication, QHBoxLayout
from PySide6.QtGui import QIcon
from PySide6.QtCore import QSize
import sys

class GridManager(QWidget):
    def __init__(self):
        super().__init__()

        self.layout_mode = "4x4"
        self.setWindowTitle("WEN Palette (4x4)")
        self.main_layout = QVBoxLayout()
        self.setLayout(self.main_layout)

        self.grid_widget = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_widget.setLayout(self.grid_layout)

        self.toolbar = QHBoxLayout()
        self.toggle_button = QPushButton("Switch to 3x3")
        self.toggle_button.clicked.connect(self.toggle_layout)
        self.toolbar.addWidget(self.toggle_button)

        self.main_layout.addLayout(self.toolbar)
        self.main_layout.addWidget(self.grid_widget)

        self.build_grid()

    def build_grid(self):
        self.clear_layout()
        size = 4 if self.layout_mode == "4x4" else 3
        self.setWindowTitle(f"WEN Palette ({self.layout_mode})")
        self.resize(100 * size, 100 * size)  # resize the palette

        for row in range(size):
            for col in range(size):
                slot_id = row * size + col + 1
                btn = QPushButton(f"Button_{slot_id}")
                btn.setFixedSize(80, 80)
                btn.setIconSize(QSize(48, 48))
                self.grid_layout.addWidget(btn, row, col)

    def clear_layout(self):
        while self.grid_layout.count():
            child = self.grid_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    def toggle_layout(self):
        if self.layout_mode == "4x4":
            self.layout_mode = "3x3"
            self.toggle_button.setText("Switch to 4x4")
        else:
            self.layout_mode = "4x4"
            self.toggle_button.setText("Switch to 3x3")
        self.build_grid()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GridManager()
    window.show()
    sys.exit(app.exec())
