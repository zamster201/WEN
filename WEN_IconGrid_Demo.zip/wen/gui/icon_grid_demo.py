from PySide6.QtWidgets import QWidget, QGridLayout, QPushButton, QApplication
from PySide6.QtGui import QIcon
from PySide6.QtCore import QSize
import sys
import os

class IconGrid(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("WEN Icon Grid Demo")
        self.setMinimumSize(400, 400)

        grid = QGridLayout()
        self.setLayout(grid)

        icons_dir = os.path.join(os.path.dirname(__file__), "..", "resources")

        for row in range(4):
            for col in range(4):
                idx = row * 4 + col + 1
                icon_name = f"icon_{idx}.ico"  # Placeholder icon name
                icon_path = os.path.join(icons_dir, icon_name)

                btn = QPushButton()
                btn.setIcon(QIcon(icon_path))
                btn.setIconSize(QSize(48, 48))
                btn.setFlat(True)

                btn.setToolTip(f"App {idx}")
                btn.setProperty("app_name", f"App_{idx}")
                btn.setProperty("action", "launch_app")
                btn.setProperty("slot_id", idx)

                btn.clicked.connect(self.button_router)
                grid.addWidget(btn, row, col)

    def button_router(self):
        sender = self.sender()
        app_name = sender.property("app_name")
        action = sender.property("action")
        slot_id = sender.property("slot_id")
        print(f"Button {slot_id}: {app_name} -> {action}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    grid = IconGrid()
    grid.show()
    sys.exit(app.exec())
